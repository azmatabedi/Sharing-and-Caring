<?php
  session_start();
 ?>
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <script src="http://code.jquery.com/jquery-2.1.4.min.js"></script>
<script>
$(function(){
    $('a').each(function(){
        if ($(this).prop('href') == window.location.href) {
            $(this).addClass('active'); $(this).parents('li').addClass('active');
        }
    });
});
</script>

  <title>

  </title>
    <link rel="stylesheet" type="text/css" 
    href="/PROJECT/css/style.css">
</head>
<body>
  <nav>
  <a href="/PROJECT/index.php" >Home</a>
  <a href="/PROJECT/mobiles.php" >Mobile Phones</a>
  <a href="/PROJECT/books.php" >Books</a>
  <a href="/PROJECT/vehicles.php" >Vehicles</a>
  <a href="/PROJECT/clothes.php" >Clothes</a>
  <a href="/PROJECT/foods.php" >Food</a>
  <a href="/PROJECT/pets.php" >Pets</a>

<?php
if (isset($_SESSION["email"])) {

  echo "<a href='/PROJECT/profile.php' >Profile</a>";
  echo "<a href='/PROJECT/logout.php' >Log Out</a>";
}
else
{
  echo "<a href='/PROJECT/login.php' >Login</a>";
  echo "<a href='/PROJECT/signup.php' >Sign Up</a>";
}

?>


<div id="search">
  <section>
<input type="text"  name="sitesearch" placeholder="Search Anything">
<button type="button"><i class="fa fa-search" ></i></button></section>
</div>
<!-- <button name="search-submit">Search</button> -->

</nav>

</body>
</html>
