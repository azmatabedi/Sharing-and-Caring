<?php
include_once 'header.php';
?>

<!DOCTYPE html>
<html>
<head>
  <title>
    Login
  </title>
</head>
<body>
<section class="my_form">
  <img src="img/user_icon.png" width="150px" class="img-responsive" >
<center><h1>Login</h1></center>

<form id="form" action="includes/login.inc.php" method="post">
  <input type="email" name="email" placeholder="Email" required>
  <span id="email" style="color: red; font: bold;" ></span>
  <input type="password" name="password" placeholder="Password" required>
  <button class="btn-success" type="submit" name="submit">Login</button>
  <br><br><a href="forgot-password.php">I Forgot My Password</a>
  <label>OR New Here? Get Started By</label>
    <br><a href="signup.php">Sign Up</a>
</form>
<section>

  <?php
    if(isset($_GET["error"]))
    {
        if($_GET["error"]=="emptyinput")
        {
            echo "<p style='color:red; margin:20px;'>Email Or Password Left Empty Try Again!</p>";
        }
       else if($_GET["error"]=="InvalidEmail")
        {
            echo "<p style='color:red; margin:20px;'>Incorrect Email Format Try Again!</p>";
        }

        else if($_GET["error"]=="emailnotexist")
        {
            echo "<p style='color:red; margin:20px;'>Incorrect Email & Password Try Again!</p>";
        }

        else if($_GET["error"]=="wrongpassword")
        {
            echo "<p style='color:red; margin:20px;'>Incorrect Password Try Again!</p>";
        }

    }
?>

</section>

</section>



</body>
<?php  include_once 'footer.php';?>
</html>
