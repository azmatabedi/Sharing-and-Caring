<?php 
if($_SERVER['HTTP_REFERER'])
{
session_start();
session_unset();
session_destroy();

header("location: index.php");
exit();


 }
 else
{
header("location: index.php");
}
 ?>
