<!DOCTYPE html>
<html>
<head>

<link rel="stylesheet" type="text/css" href="/PROJECT/css/style.css">
<title></title>
</head>
<body>






</body>
<section id="footer">
	Copyright &copy; 2020 | SIC Team.
</section>
</html>
