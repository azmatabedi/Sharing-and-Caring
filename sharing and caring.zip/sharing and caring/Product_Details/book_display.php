<?php
$sql = "SELECT product.product_id,product.pdescription,product.conditions,product.price,book.book_name,book.author_name,book.title,book.publisher ,account.fname,account.lname FROM product,book,refowner,account where product_id=book.book_id AND seller_id=ref_id AND category_id=2 AND(refowner.seler_id=account.accountID||refowner.doner_id=account.accountID) and product_id=$pid";


      $result = $conn->query($sql);
    if ($result->num_rows > 0) 
    {
    // output data of each row
      
        $row = $result->fetch_assoc();      
    }
?>
<body>
    
    <div class="container">
        <div class="card">
            <div class="container-fliud">
                <div class="wrapper row">
                    <div class="preview col-md-6">
                        
                        <div class="preview-pic tab-content">
                          <div class="tab-pane active" id="pic-1"><img src="<?php echo $row['imagesource'];?>" /></div>
                        
                        </div>
                        <p class="preview-thumbnail nav nav-tabs"></p>
                        
                    </div>
                    <div class="details col-md-6">
                        <h3 class="product-title"><?php echo $row['book_name'];?></h3>
                        <div class="rating">
                            <div class="stars">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                            </div>
                            <span class="review-no">41 reviews</span>
                        </div>
                        <p class="product-description"><strong> User Words:</strong><?php echo $row['pdescription'];?></p>
                         <p class="product-description"><strong> book author:</strong><?php echo $row['author_name'];?></p>
                          <p class="product-description"><strong> book title:</strong><?php echo $row['title'];?></p>
                           <p class="product-description"><strong> publisher:</strong><?php echo $row['publisher'];?></p>
                           
                        <h4 class="price">current price: <span>Rs: <?php echo $row['price'];?></span></h4>
                        <p class="vote"><strong>91%</strong> of buyers enjoyed this product! <strong>(87 votes)</strong></p>
                        <h5 class="sizes">Condition:
                            <span class="size" data-toggle="tooltip" title="condition"><?php echo $row['conditions'];?></span>
                            
                        </h5>
                        <h5 class="colors">colors:
                            <span class="color orange not-available" data-toggle="tooltip" title="Not In store"></span>
                            <span class="color green"></span>
                            <span class="color blue"></span>
                        </h5>
                        <div class="action">
                            <button class="add-to-cart btn btn-default" type="button">I want to buy this</button>
                            <button class="like btn btn-default" type="button"><span class="fa fa-heart"></span></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </body>
</html>