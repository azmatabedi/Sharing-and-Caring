<?php
$sql = "SELECT product.product_id,product.conditions,product.price,pet.pet_name,pet.pet_name,pet.pet_color,pet.pet_age,product.pdescription,account.fname,account.lname FROM product,pet,refowner,account where product_id=pet.pet_id AND seller_id=ref_id AND category_id=6 AND(refowner.seler_id=account.accountID||refowner.doner_id=account.accountID) and product.product_id=$pid";


      $result = $conn->query($sql);
    if ($result->num_rows > 0) 
    {
    // output data of each row
      
        $row = $result->fetch_assoc();      
    }
?>
<body>
    
    <div class="container">
        <div class="card">
            <div class="container-fliud">
                <div class="wrapper row">
                    <div class="preview col-md-6">
                        
                        <div class="preview-pic tab-content">
                          <div class="tab-pane active" id="pic-1"><img src="<?php echo $row['imagesource'];?>" /></div>
                        
                        </div>
                        <p class="preview-thumbnail nav nav-tabs"></p>
                        
                    </div>
                    <div class="details col-md-6">
                        <h3 class="product-title"><?php echo $row['pet_name'];?></h3>
                        <div class="rating">
                            <div class="stars">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                            </div>
                            <span class="review-no">41 reviews</span>
                        </div>
                        <p class="product-description">user description<?php echo $row['pdescription'];?></p>
                        <h4 class="price">current price: <span>Rs: <?php echo $row['price'];?></span></h4>
                        <h4 class="price">age : <span> <?php echo $row['pet_age'];?></span></h4>
                        <h4 class="price">color: <span> <?php echo $row['pet_color'];?></span></h4>
                        <p class="vote"><strong>91%</strong> of buyers enjoyed this product! <strong>(87 votes)</strong></p>
                        <h5 class="sizes">Condition:
                            <span class="size" data-toggle="tooltip" title="condition"><?php echo $row['conditions'];?></span>
                            
                        </h5>
                        <h5 class="colors">colors:
                            <span class="color orange not-available" data-toggle="tooltip" title="Not In store"></span>
                            <span class="color green"></span>
                            <span class="color blue"></span>
                        </h5>
                        <div class="action">
                            <button class="add-to-cart btn btn-default" type="button">I want to buy this</button>
                            <button class="like btn btn-default" type="button"><span class="fa fa-heart"></span></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </body>
</html>