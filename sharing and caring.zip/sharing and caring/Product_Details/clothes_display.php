<?php
$sql = "SELECT product.product_id,product.price,product.conditions,product.pdescription,cloths.company_name,cloths.cloth_name,cloths.color,cloths.lenght,cloths.cloth_description,account.fname,account.lname FROM product,cloths,refowner,account where product_id=cloths.cloths_id AND seller_id=ref_id AND category_id=5 AND(refowner.seler_id=account.accountID||refowner.doner_id=account.accountID)and product_id = $pid";


      $result = $conn->query($sql);
    if ($result->num_rows > 0) 
    {
    // output data of each row
      
        $row = $result->fetch_assoc();      
    }
?>
<body>
    
    <div class="container">
        <div class="card">
            <div class="container-fliud">
                <div class="wrapper row">
                    <div class="preview col-md-6">
                        
                        <div class="preview-pic tab-content">
                          <div class="tab-pane active" id="pic-1"><img src="<?php echo $row['imagesource'];?>" /></div>
                        
                        </div>
                        <p class="preview-thumbnail nav nav-tabs"></p>
                        
                    </div>
                    <div class="details col-md-6">
                        <h3 class="product-title"><?php echo $row['company_name'];?></h3>
                        <div class="rating">
                            <div class="stars">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                            </div>
                            <span class="review-no">41 reviews</span>
                        </div>
                        <p class="product-description">user words<?php echo $row['pdescription'];?></p>
                         <p class="product-description">color<?php echo $row['color'];?></p>
                          <p class="product-description">lenght<?php echo $row['lenght'];?></p>
                        <h4 class="price">current price: <span>Rs: <?php echo $row['price'];?></span></h4>
                         <p class="product-description"> cloth description  <?php echo $row['cloth_description'];?></p>
                        <p class="vote"><strong>91%</strong> of buyers enjoyed this product! <strong>(87 votes)</strong></p>
                        <h5 class="sizes">Condition:
                            <span class="size" data-toggle="tooltip" title="condition"><?php echo $row['conditions'];?></span>
                            
                        </h5>
                        <h5 class="colors">colors:
                            <span class="color orange not-available" data-toggle="tooltip" title="Not In store"></span>
                            <span class="color green"></span>
                            <span class="color blue"></span>
                        </h5>
                        <div class="action">
                            <button class="add-to-cart btn btn-default" type="button">I want to buy this</button>
                            <button class="like btn btn-default" type="button"><span class="fa fa-heart"></span></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </body>
</html>