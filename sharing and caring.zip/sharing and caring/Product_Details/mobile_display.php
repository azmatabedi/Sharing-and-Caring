<?php
$sql = "SELECT product.product_id,product.conditions,product.price,pdescription,mobiles.mobile_name,mobiles.processor,mobiles.dispaly,mobiles.memory,account.fname,account.lname FROM product,mobiles,refowner,account where product_id=mobiles.mobile_id AND seller_id=ref_id AND category_id=1 AND(refowner.seler_id=account.accountID||refowner.doner_id=account.accountID) and product_id=$pid";



      $result = $conn->query($sql);
    if ($result->num_rows > 0) 
    {
    // output data of each row
      
        $row = $result->fetch_assoc();      
    }
?>
<body>
    
    <div class="container">
        <div class="card">
            <div class="container-fliud">
                <div class="wrapper row">
                    <div class="preview col-md-6">
                        
                        <div class="preview-pic tab-content">
                          <div class="tab-pane active" id="pic-1"><img src="<?php echo $row['imagesource'];?>" /></div>
                        
                        </div>
                        <p class="preview-thumbnail nav nav-tabs"></p>
                        
                    </div>
                    <div class="details col-md-6">
                        <h3 class="product-title"><?php echo $row['mobile_name'];?></h3>
                        <div class="rating">
                            <div class="stars">
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star checked"></span>
                                <span class="fa fa-star"></span>
                                <span class="fa fa-star"></span>
                            </div>
                            <span class="review-no">41 reviews</span>
                        </div>
                        <h4 class="product-title">Product Description</h4>
                        <p class="product-description"><strong> User Words:</strong><?php echo $row['pdescription'];?></p>
                         <p class="product-description"><strong>Memory:     </strong><?php echo $row['memory'];?></p>
                          <p class="product-description"><strong>Processor: </strong><?php echo $row['processor'];?></p>
                           <p class="product-description"><strong>Display:  </strong><?php echo $row['dispaly'];?></p>
                        <h4 class="price">current price: <span>Rs: <?php echo $row['price'];?></span></h4>
                        <p class="vote"><strong>91%</strong> of buyers enjoyed this product! <strong>(87 votes)</strong></p>
                        <h5 class="sizes">Condition:
                            <span class="size" data-toggle="tooltip" title="condition"><?php echo $row['conditions'];?></span>
                            
                        </h5>
                        <h5 class="colors">colors:
                            <span class="color orange not-available" data-toggle="tooltip" title="Not In store"></span>
                            <span class="color green"></span>
                            <span class="color blue"></span>
                        </h5>
                        <div class="action">
                            <button class="add-to-cart btn btn-default" type="button">I want to buy this</button>
                            <button class="like btn btn-default" type="button"><span class="fa fa-heart"></span></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </body>
</html>