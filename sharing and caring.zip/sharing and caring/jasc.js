	function factorial(n)
	{
		if(n<=1)
			return 1;
		return n*factorial(n-1);
	}

  if(x!=null)
 {
 	var i;
	for(i=1;i<=10;i++)
		{

			
			document.write(x+ " x "+ i + " = " + x*i+ "<br>");
			document.write("Factorial Of: "+x*i+" is:"+factorial(x*i)+"<br>");
		}
}
else
{
	document.write("EMPTY");
}
function search(name)
{
	document.write(name.value);

}

function takeinput()
{
	y=prompt("Enter Value To Calculate Factorial",5);
	alert("The Factorial of "+ y+" is:"+factorial(y));

}

function seltext()
{
	var z=document.getElementByid("123");
	alert(z.innerHTML);
}
