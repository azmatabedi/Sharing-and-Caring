<?php 
function emptySignup($fname,$lname,$email,$country,$state,$city,$postal,$mobile_no,$gender,$password,$repassword,$account_type) 
{
	$result;
	if(empty($fname) || empty($lname) || empty($email) || empty($country) || empty($state)  || empty($city) || empty($postal) || empty($mobile_no) || empty($gender) || empty($password) || empty($repassword) || empty($account_type) )
	{
		$result=true;

	}
	else
	{
		$result=false;
	}
	return $result;

}


function InvalidName($fname,$lname)
{
	$result;
	if($fname===$lname || !preg_match ("/^[a-zA-Z]*$/", $fname) || !preg_match("/^[a-zA-Z]*$/", $lname))
	{
		$result=true;
	}
	else
	{
		$result=false;
	}
	return $result;

}

function InvalidEmail($email)
{
	$result;
	if(!filter_var($email,FILTER_VALIDATE_EMAIL))
	{
		$result= true;
	}
	else
	{
		$result= false;
	}
	return $result;
}


function InvalidMobileNo($mobile_no)
{
	$result;
	if(!preg_match("/^[0-9]*$/", $mobile_no))
	{
		$result=true;
	}
	else
	{
		$result=false;
	}
	return $result;

}

function PasswordMatch($password,$repassword)
{
	$result;
	if($password!==$repassword)
	{	
		$result=true;
	}
	else
		{
			$result=false;
		}
	return $result;
}

function EmailExists($conn,$email,$mobile_no)
{

	$sql="SELECT * from Account where email=? OR mobile_no=?;";
	$stmt=mysqli_stmt_init($conn);
	if(!mysqli_stmt_prepare($stmt,$sql))
	{
		header("location: ../signup.php?error=stmtfailed");
 		exit();
	}

	mysqli_stmt_bind_param($stmt,"ss",$email,$mobile_no);
	mysqli_stmt_execute($stmt);

	$resultData=mysqli_stmt_get_result($stmt);
	if($row=mysqli_fetch_assoc($resultData))
	{
		return $row;
	}
	else
	{
		$result=false;
		return $result;
	}

	mysqli_stmt_close($stmt);

}

function createAccount($conn,$fname,$lname,$email,$country,$state,$city,$postal,$mobile_no,$gender,$password,$account_type)
{	
	$sql="INSERT into ACCOUNT (fname,lname,email,country,state,city,Postal_Code,mobile_no,gender,pwd,type) values (?,?,?,?,?,?,?,?,?,?,?);";
	$stmt=mysqli_stmt_init($conn);
	if(!mysqli_stmt_prepare($stmt,$sql))
	{
		header("location: ../signup.php?error=creationstmtfailed");
 		exit();
	}

$hashed_pass=password_hash($password, PASSWORD_DEFAULT);
	mysqli_stmt_bind_param($stmt,"sssssssssss",$fname,$lname,$email,$country,$state,$city,$postal,$mobile_no,$gender,$hashed_pass,$account_type);
	mysqli_stmt_execute($stmt);
	mysqli_stmt_close($stmt);
	header("location: ../signup.php?error=none");
 		exit();
}

function emptylogin($email,$password)
{
	$result;
	if(empty($email) || empty($password))
	{
		$result=true;
	}
	else
	{
		$result=false;
	}
	return $result;

}

function loginUser($conn,$email,$password)
{
	$emailcheck=EmailExists($conn,$email,$email);
	if($emailcheck===false)
	{
		header("location: ../login.php?error=emailnotexist");
 		exit();
	}
	$pwdHashed=$emailcheck["pwd"];	//$emailcheck["pwd"]; database password of associated user

	$pwdcheck=password_verify($password, $pwdHashed);		//check hashed version of user entered password and match with database hashed password
	
	if($pwdcheck===true)
	{
		session_start();
		$_SESSION["accountid"]=$emailcheck["accountID"];
		$_SESSION["email"]=$emailcheck["email"];
		header("location: ../index.php");
 		exit();
	}
	else if($pwdcheck===false)
	{
		header("location: ../login.php?error=wrongpassword");
 		exit();
	}


}