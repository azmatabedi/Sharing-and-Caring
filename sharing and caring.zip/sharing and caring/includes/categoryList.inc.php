<!DOCTYPE html>
<html>
<head>
  <title></title>
    <!-- Bootstrap CSS -->
<!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<script src="https://kit.fontawesome.com/a076d05399.js"></script> -->
  <title></title>
  <link rel="stylesheet" type="text/css" href="Cs/style.css">

<link rel="stylesheet" type="text/css" href="Requirements/dist/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="Requirements/dist/css/bootstrap.min.css.map">

<!-- <script src="https://kit.fontawesome.com/a076d05399.js"></script> -->

<link rel="stylesheet" type="text/css" href="Requirements/a076d05399.js">
<link rel="stylesheet" type="text/css" href="Requirements/bootstrap.min.js">
<link rel="stylesheet" type="text/css" href="Requirements/jQuery-3.4.1.slim.min.js">
<link rel="stylesheet" type="text/css" href="Requirements/pooper.min.js">
</head>
  <!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS --><!-- 
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384- J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
 
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script> -->


<body>
<!--   $pname=$row["pname"];
         $seller=$row["seller_id"];
         $quaintity=$row["quaintity"];
         $price=$row["price"];
         $condition=$row["conditions"];
         $pdescription=$row["pdescription"];
         $image=$row["imagesource"];
         $image=$row["imagesource"]; -->

<?php

    if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 

$choice=$_SESSION['choice'];
$size=0;
require_once 'dbh.inc.php';
if($choice==1)
{
  $sql = " SELECT product.product_id,product.price,mobiles.mobile_name,account.state,account.city FROM product,mobiles,refowner,account where product_id=mobiles.mobile_id AND seller_id=ref_id AND category_id=1 AND(refowner.seler_id=account.accountID||refowner.doner_id=account.accountID)";



}
if($choice==2)
{
    $sql="SELECT product.product_id,product.price,book.book_name,account.state,account.city FROM product,book,refowner,account where product_id=book.book_id AND seller_id=ref_id AND category_id=$choice AND(refowner.seler_id=account.accountID||refowner.doner_id=account.accountID)";
}
if($choice==3)
{
  $sql = "SELECT product.product_id ,car.car_name ,product.price,account.state,account.city FROM product,car,refowner,account where product_id=car_id AND seller_id=ref_id AND category_id=$choice AND(refowner.seler_id=account.accountID||refowner.doner_id=account.accountID)";


}
if($choice==4)
{
   $sql=" SELECT product.product_id,product.price,food.food_name,account.state,account.city FROM product,food,refowner,account where product_id=food.food_id AND seller_id=ref_id AND category_id=$choice AND(refowner.seler_id=account.accountID||refowner.doner_id=account.accountID)";
}
if($choice==5)
{
  $sql="SELECT product.product_id,product.price,cloths.cloth_name,account.state,account.city FROM product,cloths,refowner,account where product_id=cloths.cloths_id AND seller_id=ref_id AND category_id=$choice AND(refowner.seler_id=account.accountID||refowner.doner_id=account.accountID)";


}
if($choice==6)
{
     $sql="SELECT product.product_id,product.price,pet.pet_name,account.state,account.city FROM product,pet,refowner,account where product_id=pet.pet_id AND seller_id=ref_id AND category_id=$choice AND(refowner.seler_id=account.accountID||refowner.doner_id=account.accountID)";


}

      $result = $conn->query($sql);
    if ($result->num_rows > 0) 
    {?>
        <div class="container-fluid mt-5">
  <?php if($choice==1) {?>
  <span><h1>Name Phones</h1> </span><?php }
  elseif($choice==2) {?>
  <span><h1>Books</h1></span> <?php }
  elseif($choice==3) {?>
  <span><h1>Vehicles</h1> </span><?php } 
  elseif($choice==4) {?>
  <span><h1>Foods</h1> </span><?php }
  elseif($choice==5) {?>
  <span><h1>Clothes</h1></span> <?php }
  elseif($choice==6) {?>
  <span><h1>Pets</h1></span> <?php } ?>
        <h6></h6>
      
  <div class="row justify-content-center">
      <?php 
       while($row = $result->fetch_assoc())
      {
         
      ?>
    <div class="col-md-3 col-sm-6 col-xs-12 mb-5">
      <div class="card shadow" style="width: 18rem;">
        <div class="inner">
          <img class="card-img-top" src="<?php echo $row["imagesource"];?>" alt="Card image cap">
        </div>

        <div class="card-body text-center">
        <h5 class="card-title"></h5>
        <?php 

        $price= $row["price"];
         $pid=$row["product_id"];
         $city=$row["city"];
         $state=$row["state"];
  
        if($choice==1)
                $pname=$row["mobile_name"];
        if($choice==2)
                $pname=$row["book_name"];
        if($choice==3)
                $pname=$row["car_name"];
        if($choice==4)
                $pname=$row["food_name"];
         if($choice==5)
                $pname=$row["cloth_name"];
         if($choice==6)
                $pname=$row["pet_name"];


          ?>
        <p class="card-text">Name : <?php echo $pname;?></p>
        <p class="card-text">Price : Rs.<?php echo $price;?></p>
        <p class="card-text">location : <?php echo $city." ,".$state;?></p>
        <a href="product_details.php?req=<?php echo $pid;?>" class="btn btn-success" name="viewProduct" >Check Product</a>
        
      </div>
    </div>
  </div>
  
<?php }}?>
</body>
</html>
