<?php
if (isset($_POST['submit'])) {
 	
	$fname=$_POST['fname'];
	$lname=$_POST['lname'];
	$email=$_POST['email'];
	$country=$_POST['country'];
	$state=$_POST['state'];
	$city=$_POST['city'];
	$postal=$_POST['postal'];
	$mobile_no=$_POST['mobile_no'];
	$gender=$_POST['gender'];
	$password=$_POST['password'];
	$repassword=$_POST['repassword'];
	$account_type=$_POST['account_type'];
	$agreed=$_POST['agreed'];
	if(!$agreed)
	{
		header("location: ../signup.php?error=MustacceptToterms");
 		exit();
	}

	require_once 'dbh.inc.php';
	require_once 'functions.inc.php';

	if(emptySignup($fname,$lname,$email,$country,$state,$city,$postal,$mobile_no,$gender,$password,$repassword,$account_type) !==false)
	{
		header("location: ../signup.php?error=emptyinput");
 		exit();

	}


	else if(InvalidName($fname,$lname) !==false)
	{
		header("location: ../signup.php?error=InvalidName");
 		exit();

	}

	else if(InvalidEmail($email) !==false)
	{
		header("location: ../signup.php?error=InvalidEmail");
 		exit();

	}

	else if(InvalidMobileNo($mobile_no) !==false)
	{
		header("location: ../signup.php?error=InvalidMobileNo");
 		exit();
	}

	else if(PasswordMatch($password,$repassword) !==false)
	{
		header("location: ../signup.php?error=PasswordsNotMatch");
 		exit();
	}

	else if(EmailExists($conn,$email,$mobile_no) !==false)
	{
		header("location: ../signup.php?error=emailalreadyregistered");
 		exit();
	}

	createAccount($conn,$fname,$lname,$email,$country,$state,$city,$postal,$mobile_no,$gender,$password,$account_type);

 } 
 else
 {
 	header("location: ../signup.php");
 	exit();
 }