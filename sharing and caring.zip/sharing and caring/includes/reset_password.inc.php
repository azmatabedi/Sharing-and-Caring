<?php 
if(isset($_POST['reset-password-submit']))
{
	$email=$_POST["email"];
	

}
else
{
	header("location: ../index.php");
	exit();
}