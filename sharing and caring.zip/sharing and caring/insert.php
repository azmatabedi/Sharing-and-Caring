<?php
  echo "Hello From PHP ";
$conn = mysqli_connect('localhost','root','','sic');




		if($conn->connect_error)
		{
			die("connection failed".mysqli_connect_error());
		}
		else
		{
			// $sql="insert into category(categoryid,cname) values(1,'Mobiles Phone')";
			/*$sql="CREATE table product (
    productid int unsigned AUTO_INCREMENT PRIMARY key,
    pname varchar(20) not null,
    seller_id int not null ,
    quaintity int not null,
    price int not null,
    conditions varchar(50)  not null,
    imagesource varchar(50)  UNIQUE,
    category_id int  not null,
    pdescription varchar(150) not null,
    CONSTRAINT fksid foreign key (seller_id) REFERENCES seler(seller_id) on DELETE CASCADE on UPDATE CASCADE,
    CONSTRAINT fkcid FOREIGN key (category_id) REFERENCES category(categoryid) on DELETE CASCADE on UPDATE CASCADE
    
             )";/*
            /*
             ALTER TABLE product add FOREIGN key(category_id) REFERENCES category(categoryid) on DELETE CASCADE on UPDATE CASCADE ;
              */

            // $sql="insert into product(productid,pname,seller_id,quaintity,price,conditions,imagesource,category_id,pdescription) values(3,'samsung',2,1,10000,'new','images/3.jpg',1,'48 MP camera 6.4 inches dispaly')";
            // $sql="insert into product(productid,pname,seller_id,quaintity,price,conditions,imagesource,category_id,pdescription) values(9,'2021 BMW 540',2,2,61750,'new','images/9.jpg',3,'By Brian Normile
			//Competes with: Mercedes-Benz E-Class, Audi A6, Genesis G80, Jaguar XF
			//Looks like: A 5 Series with a bigger mouth and a bit of a nip/tuck')";
           $sql="insert into product(productid,pname,seller_id,quaintity,price,conditions,imagesource,category_id,pdescription) values(19,'sheep',2,2,20000,'new','images/19.jpg',6,'this sheep belongs to hills')";
            
            /*$sql="insert into category(categoryid,cname) values (2,'Books')";*/
           // $sql ="insert into category (categoryid,cname) values(6,'Pets')";
			 if($conn->query($sql)===TRUE)
			 {
			 	echo "table created succesfully";
			 }
			 else
			 {
			 	echo "Error".$sql."<br".$conn->error;
			 }

		}
?>