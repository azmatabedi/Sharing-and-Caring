
    
function check_email_validation(emailID)
{
	if(emailID[emailID.length-3]=='.' || emailID[emailID.length-4]=='.')
		{
            atpos = emailID.indexOf("@");
            dotpos = emailID.lastIndexOf(".");
            if (atpos < 1 || ( dotpos - atpos < 2 )) {
               document.write("Please enter correct email ID")
               document.myForm.EMail.focus() ;
               return false;
            }
            return( true );

		}

}

function login_validate(email,password)
{
	confirm('inside');
	const errorElement = document.getElementById('Error');
	const form=document.getElementByid('form');
	form.addEventListener('submit', (e) =>
	{
		let messages = []
		if( !(check_email_validation(email)))
		{
			messages.push('*Please Provide Valid Email Address');
		}
		if(password.length <=6 )
		{
			messages.push('Password must be longer than 6 chracters');
		}
		if(password.length>=20)
		{
			messages.push('Password must be smaller than 20 chracters');

		}

		if(messages.length>0)
		{
			e.preventDefault()
			errorElement.innerText = messages.join(', ')
			return false;
		}
		else if(messages.length<0)
		{
			return true;
		}
	}
)

	// if( !(check_email_validation(email)))
	// {
	// 	confirm('*Please Provide Valid Email Address');
	// 	return false;
	// }
	// else
	// 	return true;
}

















	function factorial(n)
	{
		if(n<=1)
			return 1;
		return n*factorial(n-1);
	}

  if(x!=null)
 {
 	var i;
	for(i=1;i<=10;i++)
		{


			document.write(x+ " x "+ i + " = " + x*i+ "<br>");
			document.write("Factorial Of: "+x*i+" is:"+factorial(x*i)+"<br>");
		}
}
else
{
	document.write("EMPTY");
}
function search(name)
{
	document.write(name);

}

function takeinput()
{
	y=prompt("Enter Value To Calculate Factorial",5);
	alert("The Factorial of "+ y+" is:"+factorial(y));

}

function seltext()
{
	var z=document.getElementByid("123");
	alert(z.innerHTML);
}

function temp(){
	document.write('hello temp');
}
