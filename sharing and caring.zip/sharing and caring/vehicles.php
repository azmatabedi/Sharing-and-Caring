<?php
include_once 'header.php';
$_SESSION['choice']=3;

include($_SERVER['DOCUMENT_ROOT'].'/PROJECT/includes/categoryList.inc.php');
//include_once('includes/mobiles.inc.php');
include_once 'footer.php';


?>
