<?php
if($_SERVER['HTTP_REFERER']) 
{
	include_once ('LSHeader.php');

?>



<!-- HTML -->

<link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<div class="container">

        <h2 style="text-align: center;">Add Products</h2>
     <form class="form-horizontal">
<fieldset>

<!-- Form Name -->

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput">Product name</label>  
  <div class="col-md-4">
  <input id="textinput" name="pname" type="text" placeholder="" class="form-control input-md">
    
  </div>
</div>

<!-- Textarea -->
<div class="form-group">
  <label class="col-md-4 control-label" for="textarea">Description</label>
  <div class="col-md-4">                     
    <textarea class="form-control" id="textarea" name="pdescription"></textarea>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput">Price</label>  
  <div class="col-md-4">
  <input id="textinput" name="pprice" type="text" placeholder="" class="form-control input-md">
    
  </div>
</div>

<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="selectbasic">Category</label>
  <div class="col-md-4">
    <select id="selectbasic" name="pcategory" class="form-control">
      <option value="1">Clothes</option>
      <option value="2">Book</option>
      <option value="3">Pets</option>
      <option value="4">Food</option>
      <option value="5">Clothes</option>
      <option value="6">Other</option>

    </select>

  </div>
</div>
<?php
include_once'Product_Add/add_mobile.php'
?>


<!-- Text input-->
<!-- <div class="form-group">
  <label class="col-md-4 control-label" for="textinput">keyword</label>  
  <div class="col-md-4">
  <input id="textinput" name="textinput" type="text" placeholder="" class="form-control input-md">
  <span class="help-block">example:alibaba</span>  
  </div>
</div>
 -->
<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="selectbasic">Product Condition</label>
  <div class="col-md-4">
    <select id="selectbasic" name="pcondition" class="form-control">
      <option value="1">Brand New</option>
      <option value="2">Used / Second Hand</option>
    </select>
  </div>
</div>



<!-- Text input-->
<!-- <div class="form-group">
  <label class="col-md-4 control-label" for="textinput">Quantity - unit</label>  
  <div class="col-md-4">
  <input id="textinput" name="textinput" type="text" placeholder="" class="form-control input-md">
 -->    
  <!-- </div> -->
<!-- </div> -->

<!-- Text input-->
<!-- File Button --> 
<div class="form-group">
  <label class="col-md-4 control-label" for="filebutton">Product Image</label>
  <div class="col-md-4">
    <input id="filebutton" name="pimage" class="input-file" type="file">
  </div>
</div>


<!-- Textarea -->
<div class="form-group">
  <label class="col-md-4 control-label" for="textarea">Features & Specifications</label>
  <div class="col-md-4">                     
    <textarea class="form-control" id="pfands" name="textarea"></textarea>
  </div>
</div>


<!-- Button -->
<div class="form-group ">
  <label class="col-md-4 control-label" for="singlebutton"></label>
  <div class="col-md-4">
    <a href="includes/add_product.inc.php">
    	<button id="singlebutton" name="publish" class="btn btn-success">Publish  Product</button>
    </a>
  </div>
</div>


<fieldset>

    
<fieldset>
    <legend>Accepted Delivery Terms</legend>
</fieldset>

<fieldset>
    <legend>Accepted Delivery Currency</legend>
</fieldset>

<fieldset>
    <legend>Accepted Delivery Type</legend>
</fieldset>
    
    
</fieldset>


</fieldset>




</form>

</div>



<?php
	include_once ('footer.php');
}
else
{
	header('location: index.php');
}
?>