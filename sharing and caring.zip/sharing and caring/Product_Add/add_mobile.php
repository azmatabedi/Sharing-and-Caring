
<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput">Mobile name</label>  
  <div class="col-md-4">
  <input id="textinput" name="pname" type="text" placeholder="" class="form-control input-md">
    
  </div>
</div>

<!-- Textarea -->
<div class="form-group">
  <label class="col-md-4 control-label" for="textarea">Description</label>
  <div class="col-md-4">                     
    <textarea class="form-control" id="textarea" name="pdescription"></textarea>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput">Price</label>  
  <div class="col-md-4">
  <input id="textinput" name="pprice" type="text" placeholder="" class="form-control input-md">
    
  </div>
</div>

<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="selectbasic">Category</label>
  <div class="col-md-4">
    <select id="selectbasic" name="pcategory" class="form-control">
      <option value="1">Clothes</option>
      <option value="2">Book</option>
      <option value="3">Pets</option>
      <option value="4">Food</option>
      <option value="5">Clothes</option>
      <option value="6">Other</option>

    </select>
    
  </div>
</div>
