<?php
	include 'LSheader.php';
	?>
<section class="my_form">
  <img src="img/emailsent.png" width="400px" >
<center> <h1>Email Sent!</h1></center>
<center><strong style="font-size: 18px;">Kindly Check Your Email And Follow Instructions To Complete Process.</strong></center>
</section>

<?php
include 'footer.php';
?>