<?php
if (isset($_GET['search'])) 
{
  $search=$_GET['search'];
include_once('header.php');
include_once('includes/dbh.inc.php');
include_once('includes/functions.inc.php');
$size=0;

$sql="CALL search('$search')";
  $result = $conn->query($sql);
    if ($result->num_rows > 0) 
    {
      while($row = $result->fetch_assoc())
      {
         $pname[$size]=$row["car_name"];
         $price[$size]=$row["price"];
         $city[$size]=$row["city"];
         $state[$size]=$row["state"];

         // $seller[$size]=$row["seller_id"];
         // $quaintity[$size]=$row["quaintity"];
        // $price[$size]=$row["price"];
         // $condition[$size]=$row["conditions"];
         // $pdescription[$size]=$row["pdescription"];
        // $image[$size]=$row["imagesource"];
         $size++;
      }
  }
  
 else
{
  $result=false;
  echo "<br><br><br>No Result Found";
}

// echo "<br><br><br><br>";

?>


  <div class="container-fluid">
    <span><h1>Search Results</h1>
    <h6></h6></span>
  <div class="row justify-content-center">
 
 <?php
 for ($i=0; $i < $size; $i+=4) { 
 ?>
    <div class="col-md-3 col-sm-6 col-xs-12 t4">
      <div class="card shadow" style="width: 18rem;">
        <div class="inner">
          <img class="card-img-top" src="<?php echo $image[$i];?>" alt="Card image cap">
        </div>
      <div class="card-body text-center">
        <h5 class="card-title"></h5>
        <p class="card-text">Name : <?php echo $pname[$i];?></p>
        <p class="card-text">Price : Rs.<?php echo $price[$i];?></p>
        <p class="card-text">Location:<?php echo $state[$i]." ".$city[$i];?></p>
        <a href="product_details.php?req=<?php echo $pid[$i];?>" class="btn btn-success" name="viewProduct" >Check Product</a>


        

      </div>
    </div>
  </div>
  

<?php 
  if($i+1<$size)
    { 
  ?>
  <div class="col-md-3 col-sm-6 col-xs-12">
      <div class="card shadow" style="width: 18rem;">
        <div class="inner">
          <img class="card-img-top" src="<?php echo $image[$i+1];?>" alt="Card image cap">
        </div>
      <div class="card-body text-center">
        <h5 class="card-title"></h5>
        <p class="card-text">Name : <?php echo $pname[$i+1];?></p>
        <p class="card-text">Price : Rs.<?php echo $price[$i+1];?></p>
        <p class="card-text">Location:<?php echo $state[$i]." ".$city[$i];?></p>
        <a href="product_details.php?req=<?php echo $pid[$i+1];?>" class="btn btn-success" name="viewProduct" >Check Product</a>

      </div>
    </div>
  </div>

<?php } 


  if($i+2<$size)
    { 
  ?>
  <div class="col-md-3 col-sm-6 col-xs-12">
      <div class="card shadow" style="width: 18rem;">
        <div class="inner">
          <img class="card-img-top" src="<?php echo $image[$i+2];?>" alt="Card image cap">
        </div>
      <div class="card-body text-center">
        <h5 class="card-title"></h5>
        <p class="card-text">Name : <?php echo $pname[$i+2];?></p>
        <p class="card-text">Price : Rs.<?php echo $price[$i+2];?></p>
        <p class="card-text">Location:<?php echo $state[$i]." ".$city[$i];?></p>
        <a href="product_details.php?req=<?php echo $pid[$i+2];?>" class="btn btn-success" name="viewProduct" >Check Product</a>

      </div>
    </div>
  </div>

<?php } 

  if($i+3<$size)
    { 
  ?>
    <div class="col-md-3 col-sm-6 col-xs-12">
      <div class="card shadow" style="width: 18rem;">
        <div class="inner">
          <img class="card-img-top" src="<?php echo $image[$i+3];?>" alt="Card image cap">
        </div>
      <div class="card-body text-center">
        <h5 class="card-title"></h5>
        <p class="card-text">Name : <?php echo $pname[$i+3];?></p>
        <p class="card-text">Price : Rs.<?php echo $price[$i+3];?></p>
        <p class="card-text">Location:<?php echo $state[$i]." ".$city[$i];?></p>
        <a href="product_details.php?req=<?php echo $pid[$i+3];?>" class="btn btn-success" name="viewProduct" >Check Product</a>

      </div>
    </div>
  </div>

<?php } ?>
</div>
</div>
<?php  
}
 
  // mysqli_stmt_close($stmt);
 }
else
{
  header("location: index.php");
  exit();
}


include_once('footer.php');

?>