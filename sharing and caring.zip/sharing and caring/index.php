<?php
include_once 'header.php';

if(isset($_SESSION["email"]))
{
	?>
	<center><code class="bg-white text-success">You are logged In</code></center>
	<?php
}

?>