<?php
include_once 'header.php';
?>

<!DOCTYPE html>
<html>
<head>
  <title>
    Forgot Password
  </title>
</head>
<body>
<section class="my_form">
  <img src="img/reset.png" width="200px" >
<center> <h1>Reset Password</h1></center>
<center><strong style="font-size: 18px;">If you need help resetting your password, we can help by sending you a link to reset it.</strong></center>
<form id="form" action="includes/reset_password.inc.php" method="post">
  <input type="email" name="email" placeholder="Enter Your Email" required>
  <button type="submit" name="reset-password-submit">Send Email</button>
</section>
</body>
<?php  include_once 'footer.php';?>
</html>
