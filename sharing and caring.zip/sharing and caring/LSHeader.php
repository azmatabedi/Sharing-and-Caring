<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>

  </script>

  <!-- Bootstrap CSS -->
<link rel="stylesheet" type="text/css" href="Requirements/dist/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="Requirements/dist/css/bootstrap.min.css.map">

<!-- <script src="https://kit.fontawesome.com/a076d05399.js"></script> -->

<link rel="stylesheet" type="text/css" href="Requirements/a076d05399.js">
<link rel="stylesheet" type="text/css" href="Requirements/bootstrap.min.js">
<link rel="stylesheet" type="text/css" href="Requirements/jQuery-3.4.1.slim.min.js">
<link rel="stylesheet" type="text/css" href="Requirements/pooper.min.js">

<script type="text/javascript" src="js/jasc.js"></script>
  <script type="text/javascript">
    $(".nav .nav-link").on("click", function(){
   $(".nav").find(".active").removeClass("active");
   $(this).addClass("active");
});</script>

  <title></title>
</head>
<body>

  <title>

  </title>
    <link rel="stylesheet" type="text/css" 
    href="/PROJECT/Cs/style.css">
    <link rel="stylesheet" type="text/css" 
    href="/PROJECT/css/style.css">

    <!-- Header Starts from here -->
   <div class="headerblog">
    <div class="mainblog">
      <ul>
       <li><a href="/PROJECT/index.php" >Home</a></li>
       <li><a href="/PROJECT/mobiles.php" >Mobile Phones</a></li>
       <li><a href="/PROJECT/books.php" >Books</a></li>
       <li><a href="/PROJECT/vehicles.php" >Vehicles</a></li>
       <li><a href="/PROJECT/clothes.php" >Clothes</a></li>
       <li><a href="/PROJECT/foods.php" >Food</a></li>
       <li><a href="/PROJECT/pets.php" >Pets</a></li>

<?php
if (isset($_SESSION["email"])) {
  
  echo "<li><a href='/PROJECT/profile.php' >Profile</a></li>";
  echo "<li><a href='/PROJECT/logout.php' >Log Out</a></li>";
}
else
{
  echo "<li><a href='/PROJECT/login.php' >Login</a> </li>";
  echo "<li> <a href='/PROJECT/signup.php' >Sign Up</a></li>";
}

?>
  </ul>
 </div>
</div>
</body>
</html>